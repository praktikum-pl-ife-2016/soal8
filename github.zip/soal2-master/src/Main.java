/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soal;

/**
 *
 * @author Guest
 */
public class Main {
    public static void main(String[] args)
    {
        Kapal k = new Kapal("kapal","1331","Honda","polkadot");
        k.tampil();k.CaraOperasi();k.bahkanbakar();
        System.out.println("");
        Mobil m = new Mobil("Mobil","1445","Mitsubishi","kuning");
        m.tampil();m.CaraOperasi();m.bahkanbakar();System.out.println("");
        Pesawat p = new Pesawat("Pesawat","3231","Suzuki","pink");
        p.tampil();p.CaraOperasi();p.bahkanbakar();
    }
}
