/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soal;

/**
 *
 * @author Guest
 */
public class Kapal extends Laut{
  public Kapal(String nama, String no, String manufaktur, String warna)
    {
        super(nama, no, manufaktur, warna);
    }
    
 public void bahkanbakar(){
     System.out.println("Bahan bakaer yang digunakan adalah solar atau uranium");
 }
}
