src
===  
Masukkan file **.java** saja di folder ini, hapus pendefinisian package.
