/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soal;

/**
 *
 * @author Guest
 */
public abstract class Udara implements Kendaraan {
    
     private String nama, no, manufaktur, warna;

    public Udara(String nama, String no,String manufaktur, String warna)
    {
        this.nama = nama;
        this.no = no;
        this.manufaktur=manufaktur;
        this.warna = warna;
    }
    public void tampil(){
        System.out.println("Nama        : "+nama);
        System.out.println("No prod     : "+no);
        System.out.println("Manufaktur  : "+manufaktur);
        System.out.println("Warna       : "+warna);
}
    @Override
    public void CaraOperasi()
    {
        System.out.println("Cara beroperasi melayang di udara");
    }

    @Override
    public abstract void bahkanbakar();
    
}
