/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Soal;

/**
 *
 * @author Guest
 */
public interface Kendaraan {
    public abstract void bahkanbakar();
    public abstract void CaraOperasi();
}
