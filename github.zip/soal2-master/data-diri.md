Data Diri
===

Nama : Ahmad Efriza Irsad

NIM :  155150201111369
Kelas : 
TIF-E