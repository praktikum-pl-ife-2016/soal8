Screenshot
===  
Masukkan screenshot output program yang telah dibuat, screenshot **harus jelas**.
