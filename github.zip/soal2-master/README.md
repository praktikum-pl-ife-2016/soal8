Soal Praktikum Pemrograman Lanjut IF-E 2016 BAB II (Constructor dan INstance Method)
===  
####Soal 

* Sebuah idol group sedang mengadakan audisi member baru, bantu team seleksi untuk membandingkan mana kandidat yang lebih tinggi poinnya.  
Buatlah class **Kandidat** dengan atribut **nama**, **atitude**, **penampilan**, dan **suara**.  
Kemudian buatlah constructor yang berfungsi untuk mengisi semua atribut dari kandidat saat objek kandidat dibuat.  
Terakhir buat method **bandingkan** yang menerima parameter berupa objek **Kandidat** yang berguna untuk membandingkan tiap-tiap atribut yang dimiliki oleh kedua objek.
  
    * atribut **nama** berisi nama dari kandidat (tipe String).
    * atribut **atitude** berisi poin penilaian atitude dari kandidat (tipe int).
    * atribut **penampilan** berisi poin penilaian penampilan dari kandidat (tipe int).
    * atribut **suara** berisi poin penilaian suara dari kandidat (tipe int).  

* Contoh output program : 
```
Perbandingan Poin antara "nama1" dan "nama2" :
Attitude : "nama1" lebih tinggi "selisih" poin
Penampilan : "nama2" lebih tinggi "selisih" poin
Suara : "nama2" lebih tinggi "selisih" poin
==============================================
Hasil Perbandingan : "nama2" lebih unggul "selisih" poin
"Hasil perbandingan adalah berdarkan jumlah keseluruhan poin"
```
####Cara pengerjaan :

* Isi data diri dengan mengedit **data-diri.md**
* Masukkan file .java pada folder **src** (hanya file .java saja) hilangkan pendefinisian package pada setiap file .java
* Masukkan screenshot pada folder **screenshot**

**Jika pekerjaan plagiasi, maka nilai tugas ini akan di 0 kan untuk semua pihak yang terlibat.**
~~~~